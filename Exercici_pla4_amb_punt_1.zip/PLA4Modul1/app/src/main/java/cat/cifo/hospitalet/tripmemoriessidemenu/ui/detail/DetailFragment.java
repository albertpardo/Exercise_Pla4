package cat.cifo.hospitalet.tripmemoriessidemenu.ui.detail;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Contacts;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import cat.cifo.hospitalet.tripmemoriessidemenu.R;
import cat.cifo.hospitalet.tripmemoriessidemenu.model.Trip;
import cat.cifo.hospitalet.tripmemoriessidemenu.utils.DatePickerFragment;
import cat.cifo.hospitalet.tripmemoriessidemenu.utils.PictureUtils;

import static android.content.ContentValues.TAG;

public class DetailFragment extends Fragment implements DatePickerFragment.Callbacks {

    private DetailViewModel mViewModel;
    private static final String ARG_TRIP_ID = "trip_id";
    private static final String ARG_DIALOG_FRAGMENT = "date_picker_fragment";
    private static final int REQUEST_DATE = 0;
    private static final int REQUEST_CONTACT = 1;
    private static final int REQUEST_PHOTO = 2;
    private UUID mUuid;
    private Trip mTrip;
    private EditText mTripTitle, mTripCountry;
    private TextView mPhoneNumber, mCompanyName;
    private Button mDateButton, mTripSendButton, mTripContactButton;

    private ImageView mTripPhoto;
    private ImageButton mCameraButton , mTripContactCallButton;

    private File mPhotoFile;
    private Uri mPhotoUri;

    @Override
    public void onDateSelected(Date date) {
        mTrip.setDate(date);
        mDateButton.setText(mTrip.getDate().toString());
    }

    public interface Callbacks {
        void onTripDeleted(UUID trip);
    }

    private Callbacks mCallbacks = null;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mCallbacks = (Callbacks) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mUuid = (UUID) getArguments().getSerializable(ARG_TRIP_ID);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.detail_fragment, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.delete_trip) {
//            mViewModel.deleteTrip(mTrip);
            mCallbacks.onTripDeleted(mTrip.getUUID());
        } else if (item.getItemId() == R.id.update_trip) {
            mTrip.setName(String.valueOf(mTripTitle.getText()));
            mTrip.setCountry(String.valueOf(mTripCountry.getText()));
            mViewModel.updateTrip(mTrip);
            ProgressDialog pd = new ProgressDialog(getContext());
            pd.setMessage("actualitzant");
            pd.show();
            mViewModel.getUpdateResult().observe(this, trip -> {
                pd.hide();
                Navigation.findNavController(getActivity(), R.id.nav_host_fragment).navigate(R.id.nav_home, null);
            });
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.detail_fragment, container, false);

        mTripTitle = v.findViewById(R.id.trip_title);
        mTripCountry = v.findViewById(R.id.trip_country);
        mTripPhoto = v.findViewById(R.id.trip_photo);
        mCompanyName = v.findViewById(R.id.company_name);
        mPhoneNumber = v.findViewById(R.id.phone_number);

        mDateButton = v.findViewById(R.id.trip_date_button);
        mDateButton.setOnClickListener(view -> {
            DatePickerFragment datePickerFragment = new
                    DatePickerFragment().newInstace(mTrip.getDate());
            datePickerFragment.setTargetFragment(this, REQUEST_DATE);
            datePickerFragment.show(getFragmentManager(), ARG_DIALOG_FRAGMENT);
        });

        mTripSendButton = v.findViewById(R.id.trip_send_button);
        mTripSendButton.setOnClickListener(view -> {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, setTextSubject());
            sendIntent.putExtra(Intent.EXTRA_TEXT, setTextToSend());
            sendIntent.setType("text/plain");
            Intent shareIntent = Intent.createChooser(sendIntent, null);
            startActivity(shareIntent);
        });

        mTripContactButton = v.findViewById(R.id.trip_contact_button);
        mTripContactButton.setOnClickListener(view -> {
            Intent contactIntent = new Intent();
            contactIntent.setAction(Intent.ACTION_PICK);
            contactIntent.setData(ContactsContract.Contacts.CONTENT_URI);
            startActivityForResult(contactIntent, REQUEST_CONTACT);
        });

        mTripContactCallButton  = v.findViewById(R.id.companyia_call_button);
        mTripContactCallButton.setOnClickListener(view -> {
            String phoneNumber = mTrip.getPhone();

            if( phoneNumber != null && phoneNumber != "" && !phoneNumber.isEmpty()) {
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:" + phoneNumber));

                if (callIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                    Toast.makeText(getActivity(),"Fent Trucada", Toast.LENGTH_LONG).show();
                    startActivity(callIntent);
                }
            } else {
                Toast.makeText(getActivity(),"No es pot trucar per que no hi ha telefon", Toast.LENGTH_LONG).show();
            }
        });

        mViewModel = ViewModelProviders.of(this).get(DetailViewModel.class);
        mViewModel.tripLiveData.observe(getViewLifecycleOwner(), trip -> {
            mTrip = trip;
            mPhotoFile = mViewModel.getPhoto(trip);
            mPhotoUri = FileProvider.getUriForFile(requireActivity(),
                    "cat.cifo.hospitalet.tripmemoriessidemenu.fileprovider",
                    mPhotoFile);

            final Intent captureImage = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

            PackageManager packageManager = getActivity().getPackageManager();

            boolean canTakePhoto = mPhotoFile != null &&
                    captureImage.resolveActivity(packageManager) != null;

            mCameraButton = v.findViewById(R.id.trip_button_camera);
            mCameraButton.setEnabled(canTakePhoto);
            mCameraButton.setOnClickListener(view -> {
                captureImage.putExtra(MediaStore.EXTRA_OUTPUT, mPhotoUri);
                List<ResolveInfo> cameraActivities = getActivity()
                        .getPackageManager().queryIntentActivities(captureImage,
                                PackageManager.MATCH_DEFAULT_ONLY);
                for (ResolveInfo activity : cameraActivities) {
                    getActivity().grantUriPermission(activity.activityInfo.packageName,
                            mPhotoUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                }

                startActivityForResult(captureImage, REQUEST_PHOTO);
            });

            updateUI();
        });

        mViewModel.loadUUID(mUuid);

        Geocoder geocoder = new Geocoder(getContext(), Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocationName("Italia", 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Address address = addresses.get(0);
        double longitude = address.getLongitude();
        double latitude = address.getLatitude();

        Log.d(TAG, "onCreateView: " + latitude + "," + longitude);

        return v;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CONTACT && data != null) {
            Uri contactUri = data.getData();

            // String[] queryFields = new String[]{ContactsContract.Contacts.DISPLAY_NAME};

            // Obtener teléfono idea extraida de :
            // https://www.android-examples.com/get-pick-number-from-contact-list-in-android-programmatically/
            String[] queryFields = new String[]{ContactsContract.Contacts.DISPLAY_NAME,
                    ContactsContract.Contacts._ID,
                    ContactsContract.Contacts.HAS_PHONE_NUMBER };

            Cursor c = getActivity().getContentResolver()
                    .query(contactUri, queryFields, null, null, null);

            Cursor cursor2;
            try {
                if (c.getCount() == 0) {
                    return;
                }
                c.moveToFirst();
                String company = c.getString(0);
                String phone = "";
                String TempContactID = c.getString(1);

                if (Integer.valueOf(c.getString(2) ) == 1){

                    cursor2 = getActivity().getContentResolver()
                            .query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                    null,
                                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + TempContactID,
                                    null,
                                    null);
                    try {
                        cursor2.moveToFirst();
                        phone = cursor2.getString(cursor2.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    } finally {
                        cursor2.close();
                    }
                }

                mTrip.setComp(company);
                mTrip.setPhone(phone);

                updateUI();
                //mTripContactButton.setText(company + " " + phone);
            } finally {
                c.close();
            }
        } else if (requestCode == REQUEST_PHOTO) {
            //Revocar permisos de acceso  (CERRAR BRECHA SEGURIDAD)
            getActivity().revokeUriPermission(mPhotoUri,
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            updatePhotoView();
        }
    }

    private void updateUI() {
        mTripTitle.setText(mTrip.getName());
        mTripCountry.setText(mTrip.getCountry());
        mDateButton.setText(mTrip.getDate().toString());

        mCompanyName.setText(mTrip.getComp());

        String phone = mTrip.getPhone();
        mPhoneNumber.setText(phone);

        //idea extraida de :
        // https://stackoverflow.com/questions/3975141/how-to-hide-imagebutton
        if (phone != null && phone != "" && phone != " " && !phone.isEmpty()) {
            mTripContactCallButton.setVisibility(View.VISIBLE);
        } else {
            mTripContactCallButton.setVisibility(View.INVISIBLE);
        }
    }

    private String setTextSubject() {
        return getString(R.string.assumte_companyia_viatge, mTrip.getName());
    }

    private String setTextToSend() {
        return getString(R.string.viatge_text_per_enviar, mTrip.getName(), mTrip.getCountry(), mTrip.getComp());
    }

    private void updatePhotoView() {
        if (mPhotoFile == null || !mPhotoFile.exists()) {
            mTripPhoto.setImageDrawable(null);
        } else {
            Bitmap bitmap = PictureUtils.getScaledBitmap(
                    mPhotoFile.getPath(), getActivity());
            InputStream input = null;
            try {
                input = getActivity().getContentResolver().openInputStream(mPhotoUri);
                try {
                    Bitmap bitmapRotated = PictureUtils.rotateImageIfRequired(bitmap,input);
                    mTripPhoto.setImageBitmap(bitmapRotated);
                } catch (IOException e) {
                    e.printStackTrace();
                    mTripPhoto.setImageBitmap(bitmap);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}



