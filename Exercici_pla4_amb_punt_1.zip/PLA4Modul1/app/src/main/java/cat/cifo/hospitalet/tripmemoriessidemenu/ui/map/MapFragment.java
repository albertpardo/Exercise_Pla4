package cat.cifo.hospitalet.tripmemoriessidemenu.ui.map;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import cat.cifo.hospitalet.tripmemoriessidemenu.R;
import cat.cifo.hospitalet.tripmemoriessidemenu.model.Trip;

import static android.content.ContentValues.TAG;

public class MapFragment extends Fragment implements OnMapReadyCallback {

    private MapViewModel mapViewModel;
    private GoogleMap mMap;

    private LiveData<List<Trip>> mAllTrips;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        mapViewModel = ViewModelProviders.of(this).get(MapViewModel.class);
        View root = inflater.inflate(R.layout.fragment_map, container, false);

        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        return root;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);

            mAllTrips = mapViewModel.getAllTrips();

            Geocoder geocoder = new Geocoder(getContext(), Locale.getDefault());
            List<Address> addresses = null;
            Address address;
            double latitude, longitude;

            for (Trip mTrip : mAllTrips.getValue()){
                try {
                    addresses = geocoder.getFromLocationName(mTrip.getCountry(), 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (!addresses.isEmpty()) {
                    address = addresses.get(0);
                    longitude = address.getLongitude();
                    latitude = address.getLatitude();

                    Log.d(TAG, "*** onMapReady: " + mTrip.getCountry() + " (" + latitude + "," + longitude + ")");

                    mMap.addMarker(new MarkerOptions()
                            .position(new LatLng(latitude, longitude))
                            .title(mTrip.getCountry()));
                }
            }
        } else {
            Toast.makeText(getContext(), "Assegura't de donar permisos a l'aplicació per acceir a la teva localització", Toast.LENGTH_LONG).show();
        }
    }

}