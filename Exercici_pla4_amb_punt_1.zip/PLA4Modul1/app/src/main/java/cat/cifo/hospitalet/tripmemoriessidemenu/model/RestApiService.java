package cat.cifo.hospitalet.tripmemoriessidemenu.model;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface RestApiService {

    @GET("cifotestpf.php")
    Call<ArrayList<Trip>> getAllTrips();

    @GET("cifotestpf.php")
    Call<ArrayList<Trip>> getTripById(@Query("tripid") String tripid);

    @POST("cifotestpostpf.php")
    Call<Trip> insertTrip(@Body Trip trip);

}
