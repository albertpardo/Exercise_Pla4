package cat.cifo.hospitalet.tripmemoriessidemenu.ui.detail;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import java.io.File;
import java.util.UUID;

import cat.cifo.hospitalet.tripmemoriessidemenu.model.Trip;
import cat.cifo.hospitalet.tripmemoriessidemenu.model.TripRepository;

public class DetailViewModel extends AndroidViewModel {

    private TripRepository tripRepository;
    private LiveData<Trip> mTrip;
    private UUID mUUID;
    private MutableLiveData<UUID> tripIdLiveData = new MutableLiveData<>();
    private LiveData<Trip> mUpdateResult;

    public DetailViewModel(@NonNull Application application) {
        super(application);
        tripRepository = new TripRepository(application);
        mUpdateResult = getUpdateResult();
    }

    public LiveData<Trip> tripLiveData =
        Transformations.switchMap(tripIdLiveData, mUUID -> tripRepository.getTripById(mUUID));

    public void loadUUID(UUID mTripId) {
        tripIdLiveData.setValue(mTripId);
    }

    LiveData<Trip> getTrip() {
        return mTrip;
    }

    public void updateTrip(Trip trip) {
        mUpdateResult = tripRepository.insertTrip(trip);
    }

    LiveData<Trip> getUpdateResult() {
        return mUpdateResult;
    }

//    public void deleteTrip(Trip trip) {
//        tripRepository.deleteTrip(trip);
//    }

    File getPhoto(Trip trip) {
        return tripRepository.getPhotoFile(trip);
    }

}
