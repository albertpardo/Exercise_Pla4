package cat.cifo.hospitalet.tripmemoriessidemenu.ui.home;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;

import cat.cifo.hospitalet.tripmemoriessidemenu.model.Trip;
import cat.cifo.hospitalet.tripmemoriessidemenu.model.TripRepository;

public class HomeViewModel extends AndroidViewModel {

    private MutableLiveData<String> mText;
    private final TripRepository tripRepository;
    private LiveData<List<Trip>> mAllTrips;
    private LiveData<Trip> mInsertResult;

    public HomeViewModel(@NonNull Application application) {
        super(application);
        tripRepository = new TripRepository(application);
        mAllTrips = tripRepository.getAllTrips();
        mInsertResult = getInsertResult();
    }

    LiveData<List<Trip>> getAllTrips() {
        return mAllTrips;
    }

    void insert(Trip trip) {
        mInsertResult = tripRepository.insertTrip(trip);
    }

    LiveData<Trip> getInsertResult() {
        return mInsertResult;
    }

}