package cat.cifo.hospitalet.tripmemoriessidemenu.model;

import androidx.room.Entity;

import com.google.gson.annotations.SerializedName;

import java.util.Date;
import java.util.Objects;
import java.util.UUID;

@Entity(tableName = "table_trips")
public class Trip {

    @SerializedName("uuid")
    private UUID mUUID;
    @SerializedName("name")
    private String mName;
    @SerializedName("country")
    private String mCountry;
    @SerializedName("date")
    private Date mDate;
    @SerializedName("comp")
    private String mComp;
    @SerializedName("phone")
    private String mPhone;
    @SerializedName("photo")
    private String mPhoto;

    public Trip(String name, String country) {
        mUUID = UUID.randomUUID();
        this.mName = name;
        this.mCountry = country;
        this.mDate = new Date();
    }

    public Trip(String name, String country, String comp) {
        mUUID = UUID.randomUUID();
        this.mName = name;
        this.mCountry = country;
        this.mDate = new Date();
        this.mComp = comp;
    }

    public UUID getUUID() {
        return mUUID;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getCountry() {
        return mCountry;
    }

    public void setCountry(String country) {
        this.mCountry = country;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

    public void setUUID(UUID UUID) {
        mUUID = UUID;
    }

    public String getComp() {
        return mComp;
    }

    public void setComp(String comp) {
        mComp = comp;
    }

    public String getPhone() {
        return mPhone;
    }

    public void setPhone(String phone) {
        mPhone = phone;
    }

    public String getPhoto() {
        return "IMG_" + mUUID + ".jpg";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Trip trip = (Trip) o;
        return Objects.equals(getUUID(), trip.getUUID()) &&
                Objects.equals(getName(), trip.getName()) &&
                Objects.equals(getCountry(), trip.getCountry()) &&
                Objects.equals(getDate(), trip.getDate()) &&
                Objects.equals(getComp(), trip.getComp());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getUUID(), getName(), getCountry(), getDate(), getComp());
    }

    @Override
    public String toString() {
        return "Trip{" +
                "mUUID=" + mUUID +
                ", mName='" + mName + '\'' +
                ", mCountry='" + mCountry + '\'' +
                ", mDate=" + mDate +
                ", mComp='" + mComp + '\'' +
                '}';
    }
}
