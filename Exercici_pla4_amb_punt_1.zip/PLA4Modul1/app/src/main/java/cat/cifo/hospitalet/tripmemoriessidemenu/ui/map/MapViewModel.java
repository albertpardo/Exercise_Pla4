package cat.cifo.hospitalet.tripmemoriessidemenu.ui.map;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;

import cat.cifo.hospitalet.tripmemoriessidemenu.model.Trip;
import cat.cifo.hospitalet.tripmemoriessidemenu.model.TripRepository;

public class MapViewModel extends AndroidViewModel {

    private MutableLiveData<String> mText;

    private final TripRepository tripRepository;
    private LiveData<List<Trip>> mAllTrips;

    public MapViewModel(@NonNull Application application) {
        super(application);

        mText = new MutableLiveData<>();
        mText.setValue("This is map fragment");

        tripRepository = new TripRepository(application);
        mAllTrips = tripRepository.getAllTrips();

    }

    public LiveData<String> getText() {
        return mText;
    }

    LiveData<List<Trip>> getAllTrips() {
        return mAllTrips;
    }
}