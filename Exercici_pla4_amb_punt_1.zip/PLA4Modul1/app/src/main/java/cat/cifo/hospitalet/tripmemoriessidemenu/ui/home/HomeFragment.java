package cat.cifo.hospitalet.tripmemoriessidemenu.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.UUID;

import cat.cifo.hospitalet.tripmemoriessidemenu.R;
import cat.cifo.hospitalet.tripmemoriessidemenu.model.Trip;

public class HomeFragment extends Fragment {

    private HomeViewModel mViewModel;
    private View v;
    private List<Trip> trips;
    private TripListAdapter adapter;

    public static HomeFragment newInstance() {
        return new HomeFragment();
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        mViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        v = inflater.inflate(R.layout.fragment_home, container, false);

        return v;
    }

    public interface Callbacks {
        void onTripSelected(UUID trip);
    }

    private Callbacks mCallbacks = null;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mCallbacks = (Callbacks) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main_fragment, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.new_trip) {
            Trip trip = new Trip("", "");
            mViewModel.insert(trip);
            mViewModel.getInsertResult().observe(this, result -> mCallbacks.onTripSelected(trip.getUUID()));
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        adapter = new TripListAdapter(getContext());
        RecyclerView recyclerView = v.findViewById(R.id.recyclerview);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        mViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
    }

    @Override
    public void onResume() {
        super.onResume();
        mViewModel.getAllTrips().observe(this, new Observer<List<Trip>>() {
            @Override
            public void onChanged(@Nullable final List<Trip> trips) {
                adapter.setTrips(trips);
            }
        });
    }

    public class TripListAdapter extends RecyclerView.Adapter<TripListAdapter.TripViewHolder> {

        private final LayoutInflater mInflater;
        private List<Trip> mTrips;

        TripListAdapter(Context context) {
            mInflater = LayoutInflater.from(context);
        }

        class TripViewHolder extends RecyclerView.ViewHolder {
            private final TextView tripName;

            private TripViewHolder(View itemView) {
                super(itemView);
                tripName = itemView.findViewById(R.id.textView);
            }
        }

        @NonNull
        @Override
        public TripListAdapter.TripViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View itemView = mInflater.inflate(R.layout.recyclerview_item, parent, false);
            return new TripListAdapter.TripViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull TripListAdapter.TripViewHolder holder, int position) {
            final Trip current = mTrips.get(position);
            holder.tripName.setText(current.getName());
            holder.tripName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCallbacks.onTripSelected(current.getUUID());
                }
            });
        }

        void setTrips(List<Trip> trips) {
            mTrips = trips;
            notifyDataSetChanged();
        }

        @Override
        public int getItemCount() {
            if (mTrips != null)
                return mTrips.size();
            else return 0;
        }

    }

}